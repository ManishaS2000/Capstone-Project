﻿namespace recyclecollection.Models
{
    public class landfill
    {
        public int landfill_id { get; set; }
        public DateTime? Date { get; set; }

        public int weight { get; set; }

        public int Expense { get; set; }

        public string COMPANYNAME { get; set; }
    }
}
