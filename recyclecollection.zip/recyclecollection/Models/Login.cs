﻿namespace recyclecollection.Models
{
    public class Login
    {
        public required string User_id { get; set; } 

        public required string Password { get; set; }


    }
}
